import dash
from dash import html
from dash import dcc
from dash.dependencies import Input, Output, State
import pandas as pd
import plotly.express as px
import pickle
from sklearn import metrics
import numpy as np
import plotly.graph_objects as go
import matplotlib.pyplot as plt
import openmeteo_requests
import requests_cache
from retry_requests import retry
from entsoe import EntsoePandasClient
from entsoe import EntsoeRawClient
import time

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import BaggingRegressor
from xgboost import XGBRegressor
from sklearn.tree import DecisionTreeRegressor


from sklearn.feature_selection import SelectKBest # selection method
from sklearn.feature_selection import mutual_info_regression,f_regression

#import os
from dash.exceptions import PreventUpdate

import dash_bootstrap_components as dtc


#-----------------------------------------------------------------------------------------------------------------------
#
# TIME STAMPS FOR CURRENT DATA
#
#-----------------------------------------------------------------------------------------------------------------------
#getting the timestamps for t
today_date = pd.Timestamp.today()
yesterday_date = today_date - pd.Timedelta(days=1)
day_before_yesterday = today_date - pd.Timedelta(days=2)

tomorrow_date = pd.Timestamp.today() + pd.Timedelta(days=1)
formatted_date = tomorrow_date.strftime('%Y-%m-%d')
hourly_datetimes = [pd.Timestamp(f"{formatted_date} {hour}:00:00") for hour in range(24)]
#df for tomorrow dates bellow   -------------MAYBE DELETE
tomorrow_df = pd.DataFrame({
    'date': hourly_datetimes,
    'column': np.nan
})

string_tomorrow = str(tomorrow_date).split()[0]
string_today = str(today_date).split()[0]
string_yesterday = str(yesterday_date).split()[0]
string_befYest = str(day_before_yesterday).split()[0]

#-----------------------------------------------------------------------------------------------------------------------
#
#AUXILIARRY FUNCTIONS FOR THE INITIAL DATA EXTRACTION AND TREATMENT
#
#-----------------------------------------------------------------------------------------------------------------------
def get_weather_data_forecast(latitude, longitude, typeEnerg, place):
    # Setup the Open-Meteo API client with cache and retry on error
    cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
    retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
    openmeteo = openmeteo_requests.Client(session=retry_session)

    # Make sure all required weather variables are listed here
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": [latitude],
        "longitude": [longitude],
        "hourly": ["temperature_2m", "precipitation", "cloud_cover", "wind_speed_10m"],
        "forecast_days": 2
    }

    # Get weather data for the specified location
    responses = openmeteo.weather_api(url, params=params)
    response = responses[0]
    # print(f"Coordinates {response.Latitude()}°N {response.Longitude()}°E")
    # print(f"Elevation {response.Elevation()} m asl")
    # print(f"Timezone {response.Timezone()} {response.TimezoneAbbreviation()}")
    # print(f"Timezone difference to GMT+0 {response.UtcOffsetSeconds()} s")

    # Process hourly data. The order of variables needs to be the same as requested.
    hourly = response.Hourly()
    hourly_temperature_2m = hourly.Variables(0).ValuesAsNumpy()
    hourly_precipitation = hourly.Variables(1).ValuesAsNumpy()
    hourly_cloud_cover = hourly.Variables(2).ValuesAsNumpy()
    hourly_wind_speed_10m = hourly.Variables(3).ValuesAsNumpy()

    hourly_data = {"date": pd.date_range(
        start=pd.to_datetime(hourly.Time(), unit="s", utc=True),
        end=pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
        freq=pd.Timedelta(seconds=hourly.Interval()),
        inclusive="left"
    )}
    hourly_data["temperature_2m"] = hourly_temperature_2m
    hourly_data["precipitation"] = hourly_precipitation
    hourly_data["cloud_cover"] = hourly_cloud_cover
    hourly_data["wind_speed_10m"] = hourly_wind_speed_10m

    hourly_dataframe = pd.DataFrame(data=hourly_data)
    hourly_dataframe.set_index('date', inplace=True)

    if typeEnerg == 'solar':
        hourly_dataframe.drop(columns=['wind_speed_10m'], inplace=True)
    elif typeEnerg == 'wind':
        hourly_dataframe.drop(columns=['precipitation', 'cloud_cover'], inplace=True)
    elif typeEnerg == 'hydro':
        hourly_dataframe.drop(columns=['wind_speed_10m'], inplace=True)
    else:
        pass

    hourly_dataframe = hourly_dataframe.iloc[24:]

    # change the columns name

    columns = hourly_dataframe.columns
    for i in range(len(columns)):
        if columns[i] == "temperature_2m":
            hourly_dataframe.rename(columns={columns[i]: 'Temperature - ' + place}, inplace=True)
        elif columns[i] == "precipitation":
            hourly_dataframe.rename(columns={columns[i]: 'Precipitation - ' + place}, inplace=True)
        elif columns[i] == "cloud_cover":
            hourly_dataframe.rename(columns={columns[i]: 'Cloud Cover - ' + place}, inplace=True)
        elif columns[i] == "wind_speed_10m":
            hourly_dataframe.rename(columns={columns[i]: 'Wind Speed - ' + place}, inplace=True)
        else:
            pass

    return hourly_dataframe

save_string = string_today +".csv"

def get_entsoe_data_forecast():
    # Initialize the EntsoePandasClient with your API key
    api_token = '6ce99d19-962a-4b48-8269-49aebe0f12b3'
    #api_token='bb761571-188a-4b2f-8e45-3488527fc7f7'       #stor
    #api_token = '1a5dcdc8-2746-4bc9-9e00-22c53d386834'      #rony
    client = EntsoePandasClient(api_key=api_token)

    start_string = string_befYest + 'T00:00'
    end_string = string_today + 'T00:00'
    # Convert start and end date strings to Timestamps
    start = pd.Timestamp(start_string, tz='UTC')  # , tz='Europe/Lisbon')
    end = pd.Timestamp(end_string, tz='UTC')  # , tz='Europe/Lisbon')

    # Define country code for Portugal
    country_code = 'PT'

    # Query day-ahead prices
    day_ahead_prices = client.query_day_ahead_prices(country_code=country_code, start=start, end=end)

    # Query cross-border flows
    country_code_to = 'ES'
    country_code_from = 'PT'
    cross_border_flows1 = client.query_crossborder_flows(country_code_from=country_code_from,
                                                         country_code_to=country_code_to, start=start, end=end)
    cross_border_flows2 = client.query_crossborder_flows(country_code_from=country_code_to,
                                                         country_code_to=country_code_from, start=start, end=end)

    # Query load data
    load = client.query_load(country_code=country_code, start=start, end=end)

    data_list = [day_ahead_prices, cross_border_flows1, cross_border_flows2, load]

    for var in data_list:
        if isinstance(var, pd.DataFrame):
            pass
        else:
            var = pd.DataFrame(var)

    data = pd.concat(data_list, axis=1)

    data.to_csv(save_string)

    return data


def format_data_entsoe(df):
    df = df.rename_axis('date')

    df.rename(columns={0: 'day ahead prices', 1: 'PT->ES energy flow', 2: 'ES->PT energy flow'}, inplace=True)
    df = df.dropna()

    today_date = pd.Timestamp(string_today)
    hourly_datetimes = pd.date_range(start=today_date, periods=48, freq='h', tz='UTC')
    today_df = pd.DataFrame({'date': hourly_datetimes, 'day ahead prices': np.nan, 'PT->ES energy flow': np.nan,
                             'ES->PT energy flow': np.nan, 'Actual Load': np.nan})
    today_df.set_index('date', inplace=True)

    df_final = pd.concat([df, today_df])

    df_final['Actual Load 2 day trend'] = (df_final['Actual Load'].shift(48) - df_final['Actual Load'].shift(72)) / 24
    df_final['PT->ES energy flow 2 day trend'] = (df_final['PT->ES energy flow'].shift(48) - df_final['PT->ES energy flow'].shift(72)) / 24
    df_final['ES->PT energy flow 2 day trend'] = (df_final['ES->PT energy flow'].shift(48) - df_final['ES->PT energy flow'].shift(72)) / 24
    df_final['day ahead prices 2 day trend'] = (df_final['day ahead prices'].shift(48) - df_final['day ahead prices'].shift(72)) / 24

    df_final.drop(columns=['Actual Load', 'PT->ES energy flow', 'ES->PT energy flow', 'day ahead prices'], inplace=True)
    df_final = df_final.tail(24)

    return df_final


def format_saved_entsoe_data(df):
    columns = df.columns
    real_names = ['date', 'day ahead prices', 'PT->ES energy flow', 'ES->PT energy flow']
    for i in range(len(real_names)):
        df.rename(columns={columns[i]: real_names[i]}, inplace=True)

    df.set_index('date', inplace=True)
    df.index = pd.to_datetime(df.index)
    df = df.dropna()

    today_date = pd.Timestamp(string_today)
    hourly_datetimes = pd.date_range(start=today_date, periods=48, freq='h', tz='UTC')
    today_df = pd.DataFrame({'date': hourly_datetimes, 'day ahead prices': np.nan, 'PT->ES energy flow': np.nan,
                             'ES->PT energy flow': np.nan, 'Actual Load': np.nan})
    today_df.set_index('date', inplace=True)

    df_final = pd.concat([df, today_df])

    df_final['Actual Load 2 day trend'] = (df_final['Actual Load'].shift(48) - df_final['Actual Load'].shift(72)) / 24
    df_final['PT->ES energy flow 2 day trend'] = (df_final['PT->ES energy flow'].shift(48) - df_final[
        'PT->ES energy flow'].shift(72)) / 24
    df_final['ES->PT energy flow 2 day trend'] = (df_final['ES->PT energy flow'].shift(48) - df_final[
        'ES->PT energy flow'].shift(72)) / 24
    df_final['day ahead prices 2 day trend'] = (df_final['day ahead prices'].shift(48) - df_final[
        'day ahead prices'].shift(72)) / 24

    df_final.drop(columns=['Actual Load', 'PT->ES energy flow', 'ES->PT energy flow', 'day ahead prices'], inplace=True)
    df_final = df_final.tail(24)

    return df_final


def get_weather_df():
    weather_forecast = get_weather_data_forecast(sites.iloc[0][1], sites.iloc[0][2], sites.iloc[0][4], sites.iloc[0][0])

    for i in range(len(sites)):
        if i == 0:
            print('passou o 0')
        else:
            df_cycle = get_weather_data_forecast(sites.iloc[i][1], sites.iloc[i][2], sites.iloc[i][4], sites.iloc[i][0])
            weather_forecast = pd.concat([weather_forecast, df_cycle], axis=1)
    return weather_forecast


def model_picking(model):
    if model == 'Random Forrest':
        result = RandomForestRegressor()
    elif model == 'Linear Regression':
        result = LinearRegression()
    elif model == 'Decision Tree':
        result = DecisionTreeRegressor()
    elif model == 'Extreme Gradient Boosting':
        result = XGBRegressor()
    elif model == 'Bagging Regressor':
        result = BaggingRegressor()
    else:
        result = ''

    return result
#-----------------------------------------------------------------------------------------------------------------------
#
#IMPORTING DATA AND INITIAL DATA TREATMENT
#
#-----------------------------------------------------------------------------------------------------------------------
energy =  pd.read_csv('energy_data.csv')
weather =  pd.read_csv('weather_data.csv')
sites = pd.read_csv('weather_sites.csv')

sites.drop(columns=['Unnamed: 0'], inplace=True)
sites.head()

weather['date'] = pd.to_datetime(weather['date'])
weather.set_index('date', inplace=True)
energy['date'] = pd.to_datetime(energy['date'])
energy.set_index('date', inplace=True)

#creating metrics with energy information compatible with the desired forecast and the available information
energy['Actual Load 2 day trend'] = (energy['Actual Load'].shift(48) - energy['Actual Load'].shift(72)) / 24
energy['PT->ES energy flow 2 day trend'] = (energy['PT->ES energy flow'].shift(48) - energy['PT->ES energy flow'].shift(72)) / 24
energy['ES->PT energy flow 2 day trend'] = (energy['ES->PT energy flow'].shift(48) - energy['ES->PT energy flow'].shift(72)) / 24
energy['day ahead prices 2 day trend'] = (energy['day ahead prices'].shift(48) - energy['day ahead prices'].shift(72)) / 24
energy.drop(columns= ['Actual Load', 'PT->ES energy flow', 'ES->PT energy flow','day ahead prices'], inplace=True)

energy = energy.iloc[48:]
weather = weather.iloc[48:]

#aggregating the data in a single df. this data will be used to train the model.
df = pd.concat([energy, weather], axis=1)
df = df.dropna()
column_list = df.columns

df_feature_data_22_23 = df.drop(columns=['Biomass', 'Other', 'Solar', 'Wind Offshore', 'Wind Onshore', 'Hydro'])


default_features = ['PT->ES energy flow 2 day trend', 'Temperature - Aguieira', 'Temperature - Alqueva', 'Temperature - Amareleja', 'Temperature - Bemposta',
       'Temperature - Cinfaes', 'Wind Speed - Cinfaes', 'Temperature - Evora', 'Temperature - Faro', 'Temperature - Foz Tua', 'Temperature - Lisboa', 'Wind Speed - Lisboa', 'Temperature - Lousa',
       'Wind Speed - Lousa', 'Temperature - Ourique', 'Temperature - Portimao', 'Temperature - Sagres', 'Temperature - Setubal', 'Temperature - Venda Nova','Temperature - Viana do Castelo', 'Wind Speed - Viana do Castelo',
       'Temperature - Vila Pouca de Aguiar', 'Wind Speed - Vila Pouca de Aguiar']

#-----------------------------------------------------------------------------------------------------------------------
#
#REPRESENTATIVE SITES
#
#-----------------------------------------------------------------------------------------------------------------------
columns_by_site = {
    'Aguieira': ['Temperature - Aguieira', 'Precipitation - Aguieira', 'Cloud Cover - Aguieira'],
    'Alqueva': ['Temperature - Alqueva', 'Precipitation - Alqueva', 'Cloud Cover - Alqueva'],
    'Amareleja': ['Temperature - Amareleja', 'Precipitation - Amareleja', 'Cloud Cover - Amareleja'],
    'Bemposta': ['Temperature - Bemposta', 'Precipitation - Bemposta', 'Cloud Cover - Bemposta'],
    'Cinfaes': ['Temperature - Cinfaes', 'Wind Speed - Cinfaes'],
    'Evora': ['Temperature - Evora', 'Precipitation - Evora', 'Cloud Cover - Evora'],
    'Faro': ['Temperature - Faro', 'Precipitation - Faro', 'Cloud Cover - Faro'],
    'Foz Tua': ['Temperature - Foz Tua', 'Precipitation - Foz Tua', 'Cloud Cover - Foz Tua'],
    'Lisboa': ['Temperature - Lisboa', 'Precipitation - Lisboa', 'Cloud Cover - Lisboa', 'Wind Speed - Lisboa'],
    'Lousa': ['Temperature - Lousa', 'Wind Speed - Lousa'],
    'Ourique': ['Temperature - Ourique', 'Precipitation - Ourique', 'Cloud Cover - Ourique'],
    'Portimao': ['Temperature - Portimao', 'Precipitation - Portimao', 'Cloud Cover - Portimao'],
    'Sagres': ['Temperature - Sagres', 'Wind Speed - Sagres'],
    'Setubal': ['Temperature - Setubal', 'Precipitation - Setubal', 'Cloud Cover - Setubal'],
    'Venda Nova': ['Temperature - Venda Nova', 'Precipitation - Venda Nova', 'Cloud Cover - Venda Nova'],
    'Viana do Castelo': ['Temperature - Viana do Castelo', 'Wind Speed - Viana do Castelo'],
    'Vila Pouca de Aguiar': ['Temperature - Vila Pouca de Aguiar', 'Wind Speed - Vila Pouca de Aguiar']
}

fig1 = px.scatter_mapbox(sites, lat="lat", lon="long", hover_name="Place",
                        zoom=4, height=700, mapbox_style="open-street-map",
                        color="selected variables",
                        color_discrete_map={"solar": "yellow", "wind": "green", "hydro": "blue", "all": "red"},
                        )
fig1.update_traces(marker=dict(size=10))
fig1.update_layout(title="Representative Sites",
                  mapbox_style="open-street-map",
                  mapbox=dict(center=dict(lat=sites['lat'].mean(), lon=sites['long'].mean()), zoom=5))
#-----------------------------------------------------------------------------------------------------------------------
#
#DATA VISUALIZATION
#
#-----------------------------------------------------------------------------------------------------------------------
df_energy_visualization = pd.read_csv("energy_visualization.csv", sep=";")
df_energy_visualization = df_energy_visualization.replace(";", ",", regex=True)
df_energy_visualization['date'] = pd.to_datetime(df_energy_visualization['date'])
df_energy_visualization.set_index('date', inplace=True)

#print(df_energy_visualization)

column_options = [{'label': col, 'value': col} for col in df_energy_visualization.columns]

#-----------------------------------------------------------------------------------------------------------------------
#
#OBTAINING THE DATA FOR FORECASTING
#
#-----------------------------------------------------------------------------------------------------------------------
#retrieving the energy data for the forecast and formating it to the desirable specifications

try:
    energy_forecast_data = pd.read_csv(save_string)
    energy_forecast_data = format_saved_entsoe_data(energy_forecast_data)
except Exception as e:
    energy_forecast_data = get_entsoe_data_forecast()
    energy_forecast_data = format_data_entsoe(energy_forecast_data)

weather_forecast_data = get_weather_df()

#join the forecast data in a single df
forecast_X = pd.concat([energy_forecast_data, weather_forecast_data], axis=1)                                           #features for the forecast in the correct order


#-----------------------------------------------------------------------------------------------------------------------
#
#Auxiliary functions for the dash
#
#-----------------------------------------------------------------------------------------------------------------------

default_model = 'Random Forrest'

# Define the function
Ybio = df['Biomass']
Yoth = df['Other']
Ysol = df['Solar']
Ywof = df['Wind Offshore']
Ywon = df['Wind Onshore']
Yhyd = df['Hydro']
X_FS = df.drop(columns=['Biomass', 'Other', 'Solar', 'Wind Offshore', 'Wind Onshore', 'Hydro'])


def k_best_graph(var, numK):
    if var == 0:
        name = 'Biomass'
        Y_FS = Ybio
    elif var == 1:
        name = 'Other energy forms'
        Y_FS = Yoth
    elif var == 2:
        name = 'Solar'
        Y_FS = Ysol
    elif var == 3:
        name = 'Wind Offshore'
        Y_FS = Ywof
    elif var == 4:
        name = 'Wind Onshore'
        Y_FS = Ywon
    elif var == 5:
        name = 'Hydro'
        Y_FS = Yhyd
    else:
        print('The selection must be between 0 and 5')
        return None

    k_best = numK
    features_selector = SelectKBest(score_func=mutual_info_regression, k=k_best)
    features_selector.fit(X_FS, Y_FS)

    selected_features_indices = features_selector.get_support(indices=True)
    selected_features_scores = features_selector.scores_[selected_features_indices]
    selected_features_names = X_FS.columns[selected_features_indices]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        y=selected_features_names,
        x=selected_features_scores,
        orientation='h',
        marker_color='blue'
    ))
    fig.update_layout(
        title=f'Top {k_best} Best Features for forecasting {name}',
        xaxis_title='Mutual Information Score',
        yaxis_title='Features',
        yaxis=dict(autorange="reversed"),
        height=600,
        width=800
    )
    return fig

#-----------------------------------------------------------------------------------------------------------------------
#
#Auxiliary Structures for the Dash callbacks and functions
#
#-----------------------------------------------------------------------------------------------------------------------

modelo =default_model
selected_features= default_features

df_predictions = energy_forecast_data
df_predictions.drop(columns=energy_forecast_data.columns, inplace=True)

#df_predictions_percentages = df_predictions


df_test_results =df_feature_data_22_23.tail(480)
df_test_results.drop(columns=df_feature_data_22_23.columns, inplace=True)

empty_train_df = df_feature_data_22_23.iloc[:-480]
empty_train_df.drop(columns=df_feature_data_22_23.columns, inplace= True)


model_counter = 0
#-----------------------------------------------------------------------------------------------------------------------
#
#DASH
#
#-----------------------------------------------------------------------------------------------------------------------


# Define CSS style
external_stylesheets = [dtc.themes.BOOTSTRAP]

# Create the Dash app
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)


dropdown_options = [{'label': col, 'value': col} for col in df_energy_visualization.columns]

# Define the layout of the app

app.layout = html.Div([
    html.H1('Renewable Energy Generation Forecasting Tool for Portugal'),
    html.Div([
        dtc.Tooltip(
            "Press to see how to interact with the DashBoard", 
            target="help-button",
            style={'fontSize': '16px', 'textAlign': 'center', 'maxWidth': '400px', 'margin': 'auto'}
        ),
        html.Button('?', id='help-button', style={'position': 'fixed', 'top': '10px', 'right': '10px', 'backgroundColor': '#009879', 'color': 'white', 'border': 'none', 'borderRadius': '30%', 'width': '40px', 'height': '40px', 'fontSize': '15px', 'fontWeight': 'bold'}),
    ]),
    dtc.Modal([
        dtc.ModalHeader("Help"),
        dtc.ModalBody([
            html.H4("How to interact with the Dashboard:"),
            html.P("This dashboard allows you to visualize and analyze the Renewable Energy Generation Forecasting Tool for Portugal"),                    
            html.Ul([
                html.Li("'Home' - Brief project introduction"),
                html.Li("'Energy Data Visualization' - Explore the data by selecting the desired features and the period you want to see. Then, you can see some plots regarding the options you chose. Use the button 'Show Charts' to visualize a bar chart and a pie chart"),
                html.Li("'Weather Data Visualization' - This tab displays the selected points representing renewable energy production. They were chosen based on the location of different energy sources, as seen here: https://e2p.inegi.up.pt/?Lang=PT. It also shows a table with the main characteristics and a graph representing the data for each zone"),
                html.Li("'Settings' - The user can see what are the default features. Addidionaly, the user can change the features and models chosen, based on methods that evaluate the relevance of deatures."),
                html.Li("'Forecast' - This tab is where the user can see the forecast of renewable energy generation in different graphs and analyse the performance metrics of the models."),
            ]),
            html.H4('Warnings and Recomendations:'),
            html.Ul([
                html.Li('Please Read the information of each page carefully as each tab contains tips and guides on how to use this program.'),
                html.Li('The Energy Data Visualization tab takes some time to load. After pressing it don´t be surprised if nothing seems to be happening. Don´t press any other buttons or tabs, the tab will load.'),
                html.Li('This program makes use of different ML regressors. They have different limitations in this program. Please pay attention to them - They are in the settings tab.'),
                html.Li('After running a forecast. If the user desires to change their feature or model selection it is necessary to shut down and relaunch the program.')
            ])
        ]),
        dtc.ModalFooter(
            dtc.Button("Close", id="close-help", className="ml-auto")
        ),
    ], id="help-message", size="lg"),
    dcc.Tabs(id='tabs', value='tab-1', children=[
        dcc.Tab(label='Home', value='tab-1', children=[
            html.Div([
                html.H2('About the Project: '),
                html.P("The goal of this project is to forecast the renewable energy production in Portugal for the following day. This forecast was based on hourly weather and energy data."),
                html.P('The project was made by the students: Pedro Manuel nº96303 and Pedro Teixeira nº96464'),
                html.H5('Students Contribution:'),
                html.Table([
                    html.Thead(
                        html.Tr([
                            html.Th('Student'),
                            html.Th('Section')
                        ])
                    ),
                    html.Tbody([
                        html.Tr([
                            html.Td('Pedro Manuel'),
                            html.Td('Explanation Button (top right corner)')
                        ]),
                        html.Tr([
                            html.Td('Pedro Teixeira'),
                            html.Td('Data extraction & Initial data treatment')
                        ]),
                        html.Tr([
                            html.Td('Pedro Teixeira & Pedro Manuel'),
                            html.Td('Home Tab')
                        ]),
                        html.Tr([
                            html.Td('Pedro Manuel'),
                            html.Td('Energy Data Visualization')
                        ]),
                        html.Tr([
                            html.Td('Pedro Manuel'),
                            html.Td('Weather Data Visualization')
                        ]),
                        html.Tr([
                            html.Td('Pedro Teixeira'),
                            html.Td('Settings')
                        ]),
                        html.Tr([
                            html.Td('Pedro Teixeira'),
                            html.Td('Forecast')
                        ])
                    ])
                        ]),


                html.Hr(),
                html.P('Please check that the dates bellow are correct. The forecast should indicate tomorrow´s date'),
                html.P("Today's Date: " + string_today),
                html.P('Date of the forecast: ' + string_tomorrow),



            ]),
            
        ]),
        dcc.Tab(label='Energy Data Visualization', value='tab-2', children=[
            html.Div(className='row', children=[
                html.Div(className='twelve columns', children=[
                    dcc.Dropdown(
                        id='column-dropdown',
                        options=dropdown_options,
                        value='Total',
                        multi=False
                    ),
                    dcc.DatePickerRange(
                        id='date-picker-range',
                        start_date=df_energy_visualization.index.min(),
                        end_date=df_energy_visualization.index.max(),
                        display_format='YYYY-MM-DD'
                    ),
                ]),
            ]),
            html.Div(className='row', children=[
                html.Div(className='twelve columns', children=[
                    dcc.Graph(id='line-chart')
                ])
            ]),
            html.Button('Show Charts', id='show-charts-button', n_clicks=0),
            html.Div(className='row', children=[
                html.Div(className='eight columns', children=[        
                    dcc.Graph(id='bar-chart')
                ]),
                html.Div(className='four columns', children=[                
                    dcc.Graph(id='pie-chart')
                ])
            ])

        ]),

        dcc.Tab(label='Weather Data Visualization', value='tab-3', children=[
                dcc.Graph(id="mapa", figure=fig1),
                dcc.Dropdown(
                    id='site-dropdown',
                    options=[{'label': site, 'value': site} for site in columns_by_site.keys()],
                    value='Aguieira',
                    clearable=False
                ),  

                html.Div(id='output-container'),

                html.Div([
                    dcc.Loading(
                        id="loading-weather-graph",
                        type="default",
                        children=dcc.Graph(id='weather-graph')
                                )   
                        ])                            
                ]),
        dcc.Tab(label='Settings', value='tab-4', children=[
            html.Div([
                html.H2('Forecast Settings'),
                html.P('In this tab the user can change the settings of this program to his/her preference.'),
                html.P('This program has a set of default features and a default model with which it can forecast the generation data. The default options are as follows:'),
                html.P('Default Features: '),
                html.P(str(default_features)),
                html.P('Default Model: '+ default_model),
                html.Hr(),
                html.H2('Feature Selection for the Forecasting Model'),
                html.P('In this tab it is possible to analyse through the K-best feature method which are the best features for the different types of Renewable energy sources.'),
                html.P('The user is free to choose which features should be sent to the model. For it the user must select them bellow.'),
                html.H6('Choose the k number of features to rank in this slider:'),
                dcc.Slider(
                    id='k-slider',
                    min= 1,
                    max= 51,
                    step=1,
                    value=30
                ),
                html.Hr(),
                html.P('Now its time to select a type of renewable energy source.'),
                html.P('After pressing the button a graph will reveal the K best features for the chosen source of energy.'),
                html.H6('Select the Renewable energy source:'),
                dcc.Dropdown(
                    id='energy-dropdown',
                    options=[
                        {'label': 'Biomass', 'value': 0},
                        {'label': 'Other energy forms', 'value': 1},
                        {'label': 'Solar', 'value': 2},
                        {'label': 'Wind Offshore', 'value': 3},
                        {'label': 'Wind Onshore', 'value': 4},
                        {'label': 'Hydro', 'value': 5}
                    ],
                    value=2  # Default value
                ),
                html.Button('Show Graph', id='show-graph-button', n_clicks=0),
                html.Div(id='graph-container'),
                html.Hr(),
                html.H3('Select the features to send to the model:'),
                html.P('Warning, these models have some limitations regarding the number of selected features:'),
                html.P('Decision Tree Regressor: select at least 6 features, otherwise the program might crash.'),
                html.P('Extreme Gradient Boosting: select at least 5/6 features, otherwise the program might crash.'),
                html.P('Bagging Regressor: select at least 4 features, otherwise the program might crash.'),
                html.P('The random forrest is the most resilient model, it allows for a more diverse set of features. However, it is recomended a minimum of 4 features'),
                dcc.Dropdown(
                    id='variable-dropdown',
                    options=[{'label': col, 'value': col} for col in df_feature_data_22_23.columns],
                    multi=True,
                    placeholder="Select variables..."
                ),
                html.Button('Save Features', id='save-button'),
                html.Div(id='selected-variables-saved'),
                html.Hr(),
                html.H2('Model Selection'),
                html.P('In this section the user can choose the desired model for the forecast. If no action is taken the default model will be used.'),
                dcc.Dropdown(
                    id='model-dropdown',
                    options = [
                        {'label': 'Default Model - Random Forest', 'value': 0},
                        {'label': 'Decision Tree Regressor', 'value': 2},
                        {'label': 'Extreme Gradient Boosting', 'value': 3},
                        {'label': 'Bagging Regressor', 'value': 4}
                          ],
                    value=0
                ),
                html.Button('Save Model', id='save-model-button'),
                html.Div(id='selected-model-saved')


                ])








        ]),
        dcc.Tab(label='Forecast', value='tab-5', children=[
            html.Div([
                html.H3('Forecast Section.'),
                html.Hr(),
                html.P('Please confirm that these are your selected features : '),
                html.Div(id='starting-model-setup'),
                html.P(id='selected-features-string'),
                html.P('And Model: ', id='model-info'),
                html.Button('Refresh', id='refresh-button'),
                html.Hr(),
                html.P('Press the Run button in order to generate the forecast. This process usually takes some time. It will take longer if more features are selected.'),
                html.P('The system will be completed when 6 check messages appear bellow de button. Please be patient.'),
                html.Button('Run', id='run-model'),
                html.Div(id='model-check-1'),
                html.Div(id='model-check-2'),
                html.Div(id='model-check-3'),
                html.Div(id='model-check-4'),
                html.Div(id='model-check-5'),
                html.Div(id='model-check-6'),
                html.Hr(),
                html.H4('Plotting Forecast'),
                html.P('In this section it is possible to plot different plots for a better visualization of the forecast.'),
                html.H5('Line Plot:'),
                dcc.Dropdown(
                    id='energyF-dropdown',
                    options=[
                        {'label': 'Wind Onshore', 'value': 'Wind Onshore'},
                        {'label': 'Wind Offshore', 'value': 'Wind Offshore'},
                        {'label': 'Biomass', 'value': 'Biomass'},
                        {'label': 'Solar', 'value': 'Solar'},
                        {'label': 'Hydro', 'value': 'Hydro'},
                        {'label': 'Other', 'value': 'Other'},
                        {'label': 'Total Renewable Energy', 'value': 'Total'}
                    ],
                    multi=True,
                    value=[],
                    placeholder="Select which value you wish to see on the line plot..."
                ),
                html.Button('Show Plot', id='show-plot-button'),
                html.Div(id='plot-container'),
                html.Hr(),
                html.H5('Relative Values Pie-Chart: '),
                dcc.Slider(
                    id='date-slider',
                    min=0,
                    max=23,
                    step=1,
                    value=0,
                    marks={i: {'label': str(i) + ':00'} for i in range(len(df_predictions))}
                ),
                dcc.Graph(id='forecast-pie-chart'),
                html.Hr(),
                html.H4('Model evaluation metrics'),
                html.P('This program ran 6 models in order to do the forecast requested, one for each energy type.'),
                html.P('Select one of the models bellow in order to see its evaluation metrics.'),
                dcc.Dropdown(
                    id='metrics-dropdown',
                    options=[
                        {'label': 'Wind Onshore', 'value': 'Wind Onshore'},
                        {'label': 'Wind Offshore', 'value': 'Wind Offshore'},
                        {'label': 'Biomass', 'value': 'Biomass'},
                        {'label': 'Solar', 'value': 'Solar'},
                        {'label': 'Hydro', 'value': 'Hydro'},
                        {'label': 'Other', 'value': 'Other'},
                    ],
                    multi=False,
                    value=[],
                    placeholder="Select which model you want to see the evaluation results..."
                ),
                html.Button('Show Metrics Table', id= 'metrics-button'),
                html.Div(id='table-container')
            ])
        ])
])
])


#-----------------------------------------------------------------------------------------------------------------------
#
#CALL BACKS AND RESPECTIVE FUNCTIONS
#
#-----------------------------------------------------------------------------------------------------------------------
@app.callback(
    [Output('weather-graph', 'figure'),
     Output('output-container', 'children')],
    [Input('site-dropdown', 'value')]
)
def update_graph_and_table(selected_site):
    # Atualiza o gráfico
    weather_data = update_weather_graph(selected_site)
    # Atualiza a tabela
    table_data = update_weather_table(selected_site)
    # Retorna tanto os dados para o gráfico quanto para a tabela
    return weather_data, table_data

# Função para atualizar o gráfico com base no local selecionado
def update_weather_graph(selected_site):
    # Obtenha as colunas correspondentes ao local selecionado
    columns = columns_by_site[selected_site]
    # Crie os traços para o gráfico
    traces = []
    for column in columns:
        trace = go.Scatter(
            x=weather.index,
            y=weather[column],
            mode='lines',
            name=column
        )
        traces.append(trace)
    # Layout do gráfico
    graph_title = f'Weather Data for {selected_site}'
    layout = go.Layout(
        title=dict(text=f'<b>{graph_title}</b>', x=0.5, y=0.9, xanchor='center', yanchor='top'),  # Título em negrito e centrado
        xaxis=dict(title='Date'),
        yaxis=dict(title='Value')
    )
    # Retorne a figura do gráfico
    return {'data': traces, 'layout': layout}


# Função para atualizar a tabela com base no local selecionado
def update_weather_table(selected_site):
    # Obter as colunas correspondentes ao sítio selecionado
    columns = columns_by_site[selected_site]
    
    # Filtrar o dataframe para selecionar apenas as colunas do sítio
    selected_columns = [col for col in weather.columns if any(col.startswith(column) for column in columns)]
    selected_data = weather[selected_columns]
    
    # Calcular estatísticas resumidas
    summary_stats = selected_data.describe().transpose().reset_index()
    summary_stats.rename(columns={'index': 'Feature'}, inplace=True)
    
    # Criar o título da tabela
    table_title = f"Summary Stats for {selected_site}"
    
    # Transformar os dados em uma tabela HTML
    table = html.Table([
        html.Caption(html.Strong(table_title), style={'caption-side': 'top', 'text-align': 'center'}),  # Título centralizado acima da tabela e em negrito
        html.Thead(
            html.Tr([
                html.Th("Feature", style={'text-align': 'center', 'font-weight': 'bold'}),  # Estilo diferente para a coluna "Feature"
                *[html.Th(col, style={'text-align': 'center'}) for col in summary_stats.columns[1:]]  # Centralizar o texto das colunas, excluindo a primeira coluna
            ])
        ),
        html.Tbody([
            html.Tr([
                html.Td(summary_stats.iloc[i]['Feature'], style={'padding-left': '20px', 'font-weight': 'bold'}),  # Estilo diferente para a coluna "Feature"
                *[html.Td(summary_stats.iloc[i][col], style={'text-align': 'center'}) for col in summary_stats.columns[1:]]  # Centralizar o texto das células, excluindo a primeira coluna
            ]) for i in range(len(summary_stats))
        ])
    ], style={'margin': 'auto'})  # Centralizar a tabela
    
    # Retornar a tabela HTML
    return table

colors = {
    'Hydro': 'hsl(230, 100%, 50%)',  # Azul
    'Solar': 'hsl(60, 100%, 50%)',  # Amarelo
    'Biomass': 'hsl(30, 100%, 40%)',  # Castanho
    'Other': 'hsl(30, 100%, 50%)',  # Laranja
    'Wind Onshore': 'hsl(100, 100%, 35%)',  # Verde
    'Wind Offshore': 'hsl(100, 100%, 25%)',  # Verde escuro
    'Total': 'hsl(0, 0%, 70%)'  # Cinza (Cor padrão)
}


@app.callback(
    [Output('bar-chart', 'figure'),
     Output('pie-chart', 'figure')],
    [Input('show-charts-button', 'n_clicks')],
    [State('column-dropdown', 'value'),
     State('date-picker-range', 'start_date'),
     State('date-picker-range', 'end_date')],
    prevent_initial_call=True
)
def update_charts(n_clicks, selected_column, start_date, end_date):
    if n_clicks:
        filtered_df = df_energy_visualization.loc[start_date:end_date]
        
        # Bar Chart
        data_bar = []
        for column in filtered_df.columns[:-1]:  # Excluir a coluna 'Total'
            trace_bar = go.Bar(
                x=filtered_df.index,
                y=filtered_df[column],
                name=column,
                marker=dict(color=colors[column])
            )
            data_bar.append(trace_bar)
        layout_bar = go.Layout(
            title='Energy Production by Source',
            xaxis=dict(title='Date'),
            yaxis=dict(title='Energy Production'),
            barmode='stack'
        )
        bar_fig = {'data': data_bar, 'layout': layout_bar}

        # Pie Chart
        total_column = 'Total'
        labels = filtered_df.columns[:-1]
        values = [(filtered_df[column].sum() / filtered_df[total_column].sum()) * 100 for column in labels]
        pie_trace = go.Pie(
            labels=labels,
            values=values,
            hole=0.4,
            marker=dict(colors=[colors[column] for column in labels])  # Define as cores conforme o dicionário de cores
        )
        pie_fig = go.Figure(data=[pie_trace])
        pie_fig.update_layout(title='Share of Energy Production by Source')

        return bar_fig, pie_fig

    return {}, {}



@app.callback(
    Output('line-chart', 'figure'),
    [Input('column-dropdown', 'value'),
     Input('date-picker-range', 'start_date'),
     Input('date-picker-range', 'end_date')]
)
def update_line_chart(selected_column, start_date, end_date):
    filtered_df = df_energy_visualization.loc[start_date:end_date]
    
    # Line Chart
    trace_line = go.Scatter(
        x=filtered_df.index,
        y=filtered_df[selected_column],
        mode='lines',
        name=selected_column,
        line=dict(color=colors[selected_column])  # Atribuir cor com base no nome da feature
    )
    layout_line = go.Layout(
        title=f'Energy Visualization for {selected_column}',
        xaxis=dict(title='Date'),
        yaxis=dict(title=selected_column)
    )
    line_chart = {'data': [trace_line], 'layout': layout_line}
    
    return line_chart


@app.callback(
    Output('graph-container', 'children'),
    [Input('show-graph-button', 'n_clicks')],
    [State('energy-dropdown', 'value'),
     State('k-slider', 'value')]
)
def update_graph(n_clicks, energy_type, numK):
    if n_clicks is None:
        return dash.no_update
    if n_clicks > 0:
        fig = k_best_graph(energy_type, numK)
        return dcc.Graph(figure=fig)

@app.callback(
    Output('selected-variables-saved', 'children'),
    [Input('save-button', 'n_clicks')],
    [State('variable-dropdown', 'value')]
)
def save_selected_variables(n_clicks, selected_variables):
    global selected_features
    if n_clicks and selected_variables:
        selected_features = selected_variables
        return "Features saved. Please move to the next tab."
    elif n_clicks and not selected_variables:
        selected_features = default_features
        return "Please Select a Variable. If no Variable is selected the default features will be chosen"
    elif not n_clicks and selected_variables:
        selected_features = default_features
        return "Please confirm selection. If there is no confirmation the default features will be chosen"
    else:
        selected_features = default_features
        return "Current selection: Default Features"

    print('features: ' + selected_features)

@app.callback(
    Output('selected-model-saved','children'),
    [Input('save-model-button','n_clicks')],
    [State('model-dropdown', 'value')]
)
def save_selected_model(n_clicks, selected_model):
    model_counter = 0
    global modelo
    if not n_clicks:
        modelo = 'Random Forrest'
        return "Current Model: Random Forrest"
    elif n_clicks and selected_model == 0:
        modelo = 'Random Forrest'
        return "Current Model: Random Forrest"
    elif n_clicks and selected_model == 1:
        modelo = 'Linear Regression'
        return "Current Model: Linear Regression"
    elif n_clicks and selected_model == 2:
        modelo = 'Decision Tree'
        return "Current Model: Decision Tree"
    elif n_clicks and selected_model ==3:
        modelo = "Extreme Gradient Boosting"
        return "Current Model: Extreme Gradient Boosting"
    elif n_clicks and selected_model == 4:
        modelo = "Bagging Regressor"
        return "Current Model: Bagging Regressor"


@app.callback(
    [Output('selected-features-string', 'children'),
     Output('model-info', 'children')],
    [Input('refresh-button', 'n_clicks')]
)
def update_text(n_clicks):
    if n_clicks:
        # Update the text of 'selected-features' and 'model-info' with the most recent values
        return str(selected_features), 'And Model: ' + str(modelo)
    else:
        # Return the current values if the button has not been clicked yet
        return str(selected_features), 'And Model: ' +str(modelo)


#-----------------------------------------------------------------------------------------------------------------------
#
#CALL BACKS AND RESPECTIVE FUNCTIONS FOR THE ML MODELS
#
#-----------------------------------------------------------------------------------------------------------------------
@app.callback(
    Output('starting-model-setup','children'),
    [Input('run-model','n_clicks')]
)

def model_def(n_clicks):
    global model, x_train, x_test, x_forecast

    if n_clicks:
        model = model_picking(modelo)

        columns_to_keep = set(selected_features)
        columns_to_drop = list(set(df_feature_data_22_23.columns) - columns_to_keep)

        x_train = df_feature_data_22_23.iloc[:-480]
        x_train.drop(columns=columns_to_drop, inplace=True)
        x_test = df_feature_data_22_23.tail(480)
        x_test.drop(columns=columns_to_drop, inplace=True)


        x_forecast = forecast_X
        x_forecast.drop(columns=columns_to_drop, inplace=True)


@app.callback(
    Output('model-check-1','children'),
    [Input('run-model','n_clicks')]
)

def model_Biomass(n_clicks):
    if n_clicks :

        y_train_bio = Ybio.iloc[:-480]
        y_test_bio =  Ybio.tail(480)


        model.fit(x_train,y_train_bio)
        y_pred_test_bio = model.predict(x_test)
        df_test_results['Biomass-Test'] = y_pred_test_bio
        df_test_results['Biomass-Real'] = y_test_bio


        predictions_bio = model.predict(x_forecast)

        df_predictions['Biomass'] = predictions_bio

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i]/ df_predictions['Total'])*100

        return 'Check model 1'

@app.callback(
    Output('model-check-2','children'),
    [Input('run-model','n_clicks')]
)

def model_Other(n_clicks):
    if n_clicks:

        y_train_oth = Yoth.iloc[:-480]
        y_test_oth =  Yoth.tail(480)

        model.fit(x_train,y_train_oth)
        y_pred_test_oth = model.predict(x_test)
        df_test_results['Other-Test'] = y_pred_test_oth
        df_test_results['Other-Real'] = y_test_oth


        predictions_oth = model.predict(x_forecast)

        df_predictions['Other'] = predictions_oth

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i] / df_predictions['Total']) * 100

        return 'Check model 2'


@app.callback(
    Output('model-check-3','children'),
    [Input('run-model','n_clicks')]
)

def model_Solar(n_clicks):
    if n_clicks:

        y_train_sol = Ysol.iloc[:-480]
        y_test_sol =  Ysol.tail(480)

        model.fit(x_train,y_train_sol)
        y_pred_test_sol = model.predict(x_test)
        df_test_results['Solar-Test'] = y_pred_test_sol
        df_test_results['Solar-Real'] = y_test_sol


        predictions_sol = model.predict(x_forecast)

        df_predictions['Solar'] = predictions_sol

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i] / df_predictions['Total']) * 100

        return 'Check model 3'


@app.callback(
    Output('model-check-4','children'),
    [Input('run-model','n_clicks')]
)

def model_Wind_Offshore(n_clicks):
    if n_clicks:

        y_train_wof = Ywof.iloc[:-480]
        y_test_wof =  Ywof.tail(480)

        model.fit(x_train,y_train_wof)
        y_pred_test_wof = model.predict(x_test)
        df_test_results['Wind Offshore-Test'] = y_pred_test_wof
        df_test_results['Wind Offshore-Real'] = y_test_wof


        predictions_wof = model.predict(x_forecast)

        df_predictions['Wind Offshore'] = predictions_wof

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i] / df_predictions['Total']) * 100

        return 'Check model 4'

@app.callback(
    Output('model-check-5','children'),
    [Input('run-model','n_clicks')]
)

def model_Wind_Onshore(n_clicks):
    if n_clicks:

        y_train_won = Ywon.iloc[:-480]
        y_test_won =  Ywon.tail(480)

        model.fit(x_train,y_train_won)
        y_pred_test_won = model.predict(x_test)
        df_test_results['Wind Onshore-Test'] = y_pred_test_won
        df_test_results['Wind Onshore-Real'] = y_test_won


        predictions_won = model.predict(x_forecast)

        df_predictions['Wind Onshore'] = predictions_won

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i] / df_predictions['Total']) * 100

        return 'Check model 5'

@app.callback(
    Output('model-check-6','children'),
    [Input('run-model','n_clicks')]
)

def model_Hydro(n_clicks):
    if n_clicks:

        y_train_hyd = Yhyd.iloc[:-480]
        y_test_hyd =  Yhyd.tail(480)

        model.fit(x_train,y_train_hyd)
        y_pred_test_hyd = model.predict(x_test)
        df_test_results['Hydro-Test'] = y_pred_test_hyd
        df_test_results['Hydro-Real'] = y_test_hyd


        predictions_hyd = model.predict(x_forecast)

        df_predictions['Hydro'] = predictions_hyd

        if len(df_predictions.columns) == 6:
            df_predictions['Total'] = df_predictions.sum(axis=1)
            columns = df_predictions.columns[:-1]
            for i in columns:
                string_column = str(i) + ' Percentage'
                df_predictions[string_column] = (df_predictions[i] / df_predictions['Total']) * 100
        return 'Check model 6'


#-----------------------------------------------------------------------------------------------------------------------
#
#Other Dash callbacks and functions
#
#-----------------------------------------------------------------------------------------------------------------------


@app.callback(
    Output('energyF-dropdown', 'disabled'),
    [Input('model-check-1', 'children'),
     Input('model-check-2', 'children'),
     Input('model-check-3', 'children'),
     Input('model-check-4', 'children'),
     Input('model-check-5', 'children'),
     Input('model-check-6', 'children')
     ]
)
def enable_dropdown(check_1,check_2,check_3,check_4,check_5,check_6):
    if check_1 == 'Check model 1' and check_2 == 'Check model 2' and check_3 == 'Check model 3' and check_4 == 'Check model 4' and check_5 == 'Check model 5' and check_6 == 'Check model 6':
        print('')
        return False
    else:
        return True

@app.callback(
    Output('plot-container', 'children'),
    [Input('show-plot-button', 'n_clicks')],
    [State('energyF-dropdown', 'value')]
)
def plot_selected_columns(n_clicks, selected_columns):
    if n_clicks is None:
        return dash.no_update

    if not selected_columns:
        return "Please select at least one column."

    # Plotly figure initialization
    fig = go.Figure()

    # Loop through selected columns and add traces to the figure
    for column in selected_columns:
        # Add trace for each selected column
        fig.add_trace(go.Scatter(
            x=df_predictions.index,  # Assuming indices are dates
            y=df_predictions[column],
            mode='lines',
            name=column
        ))

    # Update layout
    fig.update_layout(
        title='Energy Forecast',
        xaxis_title='Date',
        yaxis_title='MW'
    )

    # Return the graph component
    return dcc.Graph(figure=fig)



@app.callback(
    Output('forecast-pie-chart', 'figure'),
    [Input('date-slider', 'value')]
)
def update_pie_chart(selected_index):
    # Get the percentages for the selected row
    df_percentages = df_predictions.iloc[:, -6:]
    percentages = df_percentages.iloc[selected_index]

    # Create pie chart trace
    trace = go.Pie(labels=percentages.index, values=percentages.values, hole=0.3)

    # Create layout
    layout = go.Layout(title='Percentage Distribution for ' + string_tomorrow)

    # Create figure
    fig = go.Figure(data=[trace], layout=layout)

    return fig


@app.callback(
    Output('metrics-dropdown', 'disabled'),
    [Input('model-check-1', 'children'),
     Input('model-check-2', 'children'),
     Input('model-check-3', 'children'),
     Input('model-check-4', 'children'),
     Input('model-check-5', 'children'),
     Input('model-check-6', 'children')
     ]
)
def enable_metrics_dropdown(check_1,check_2,check_3,check_4,check_5,check_6):
    if check_1 == 'Check model 1' and check_2 == 'Check model 2' and check_3 == 'Check model 3' and check_4 == 'Check model 4' and check_5 == 'Check model 5' and check_6 == 'Check model 6':
        print('')
        return False
    else:
        return True


@app.callback(
    Output('table-container', 'children'),
    [Input('metrics-button', 'n_clicks')],
    [State('metrics-dropdown', 'value')]
)

def metrics_table(n_clicks, model_selection):
    if n_clicks is None:
        return dash.no_update

    if not model_selection:
        return "Please select one model."

    #calculate the metrics
    string_real = model_selection + '-Real'
    string_test = model_selection + '-Test'

    y_real = df_test_results[string_real]
    y_test = df_test_results[string_test]

    MAE = metrics.mean_absolute_error(y_real, y_test)
    MBE = np.mean(y_real - y_test)
    MSE = metrics.mean_squared_error(y_real, y_test)
    RMSE = np.sqrt(metrics.mean_squared_error(y_real, y_test))
    cvRMSE = RMSE / np.mean(y_real)
    NMBE = MBE / np.mean(y_real)


    metrics_dic = {' Mean Absolute Error': MAE,
                   ' Mean Bias Error': MBE,
                   'Mean Squared Error' : MSE,
                   'Root Mean Squared Error': RMSE,
                   'Coefficient of Variation of Root Mean Squared Error': cvRMSE,
                   'Normalized Mean Bias Error': NMBE
                   }



    # Create the table
    table_rows = []
    for metric_name, metric_value in metrics_dic.items():
        row = html.Tr([
            html.Td(metric_name),
            html.Td(str(metric_value))
        ])
        table_rows.append(row)

    # Assemble the table
    table = html.Table([
        html.Thead(html.Tr([html.Th('Metric'), html.Th('Value')])),
        html.Tbody(table_rows)
    ])

    return table

@app.callback(
    Output("help-message", "is_open"),
    [Input("help-button", "n_clicks"), Input("close-help", "n_clicks")],
    [State("help-message", "is_open")],
)
def toggle_modal(n1, n2, is_open):
    if n1 or n2:
        return not is_open
    return is_open  


print('Don´t be alarmed by the warning messages. Please search for the link in this section.')
# Run the app
if __name__ == '__main__':
    app.run_server(debug=True)