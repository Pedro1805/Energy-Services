import pandas as pd
from entsoe import EntsoePandasClient
from entsoe import EntsoeRawClient

# Initialize the EntsoePandasClient with your API key
api_token = '6ce99d19-962a-4b48-8269-49aebe0f12b3'
client = EntsoePandasClient(api_key= api_token)

# Define parameters for the data query
start = pd.Timestamp('2022-01-01T00:00', tz='Europe/Lisbon')  # Start date in Lisbon timezone   antigo = '2023-01-01T00:00'
end = pd.Timestamp('2023-01-01T00:00', tz='Europe/Lisbon')  # End date in Lisbon timezone       antigo = '2024-01-01T00:00'
country_code = 'PT'  # Country code for Portugal
country_code_to = 'ES'
country_code_from = 'PT'

generation_data = client.query_generation(country_code= country_code, start= start, end= end, psr_type=None)

day_ahead_prices = client.query_day_ahead_prices(country_code= country_code, start= start, end= end)

cross_border_flows1 = client.query_crossborder_flows(country_code_from= country_code_from, country_code_to= country_code_to, start= start, end= end)
cross_border_flows2 = client.query_crossborder_flows(country_code_from= country_code_to, country_code_to= country_code_from, start= start, end= end)

load = client.query_load(country_code= country_code, start= start, end= end)

generation_data.to_csv('generation_data2022.csv')
day_ahead_prices.to_csv('day_ahead_prices_data2022.csv')
cross_border_flows1.to_csv('cross_border_flows_data2022_PT-ES.csv')
cross_border_flows2.to_csv('cross_border_flows_data2022_ES-PT.csv')
load.to_csv('load_data2022.csv')