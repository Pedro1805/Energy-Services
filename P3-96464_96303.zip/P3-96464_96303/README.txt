Before running the P3_96303_96464.py, please make sure you have installed in your environment 
the following python libraries:
-dash
-pandas
-plotly.express
-sklearn 
-numpy 
-plotly.graph_objects 
-matplotlib
-openmeteo_requests
-requests_cache
-retry_requests 
-entsoe 
-xgboost 
---------------------------------------------------------------------------------------------
Additionaly, due to the import of data from the entsoe transparency site, please refrain from using this program between 00:00 and 2:00. As the necessary data from this website might not be
available at that time. The program will not work if some of the data from this website is
missing.
If this has already happened and the program is crashing, please delete the csv file with todays date (eg.: "2024-04-14.csv") and run the program after the time window defined previously.
----------------------------------------------------------------------------------------------
In this folder, it is also included the files used in the first data extraction and data treatment.
-----------------------------------------------------------------------------------------------Dash is running on http://127.0.0.1:8050/