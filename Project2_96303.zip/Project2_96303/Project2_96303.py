# -*- coding: utf-8 -*-
"""
Created on Fri Mar 22 13:22:22 2024

@author: Pedro Manuel
"""

#Import the main libraries
import dash
from dash import html, dcc, callback, Input, Output, State
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import pickle
from sklearn import metrics
import numpy as np
import plotly.graph_objects as go
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, BaggingRegressor, GradientBoostingRegressor
from dash.exceptions import PreventUpdate

colors = {
    'background': '#f0f2f6',
    'text': '#000000',
    'primary': '#009879',
    'secondary': '#FFFFFF'
}


#Define CSS style
external_stylesheets = [dbc.themes.BOOTSTRAP]

white_text_style = {'color': 'white'}

X = None
Y = None

X_train = None
X_test = None
y_train = None
y_test = None
#y_pred_list = []
#y_pred_2019 = []
X_2019 = None

#Load data

################# Data for RAW DATA AND EDA ######################

merged_data = pd.read_csv("merged_data.csv", index_col=0, parse_dates=True, encoding='ISO-8859-1')
columns = merged_data.columns.tolist()
start_date = merged_data.index.min()
end_date = merged_data.index.max()

# Set a variable with the cut-off date for the 2019 set
test_cutoff_date = '2019-01-01'

# Split the dataset into training and test sets
df_data = merged_data.loc[merged_data.index < test_cutoff_date] #dataset with values from 2017 and 2018
df_2019 = merged_data.loc[merged_data.index >= test_cutoff_date] #dataset with values from 2019 (to predict)

#Clean the dataset with values from 2017 and 2018
df_data = df_data.dropna()
#df_data = df_data.iloc[2:]


################# Data for FS AND MODELS ######################

df_final = pd.read_csv("df_final.csv", index_col=0, parse_dates=True)

df_dataFS = df_final.copy()
df_dataFS = df_dataFS.drop("Power (kW)", axis=1)

# 2019 data to test model
df_real = pd.read_csv('df_19.csv')
df_real['Date'] = pd.to_datetime(df_real['Date'])
y=df_real['Power (kW)'].values


fig1 = px.line(df_real, x='Date', y='Power (kW)')

# Define auxiliary functions
def generate_table(dataframe, max_rows=10):
    # Adicione um estilo à tabela
    table_style = {
        'width': '100%',
        'borderCollapse': 'collapse',
        'margin': '25px 0',
        'fontSize': '0.9em',
        'fontFamily': 'Arial, sans-serif',
        'minWidth': '400px',
        'boxShadow': '0 0 20px rgba(0, 0, 0, 0.15)',
        'borderRadius': '10px',  # Adicione bordas arredondadas
        'overflow': 'hidden'
    }

    # Adicione um estilo para as células do cabeçalho
    th_style = {
        'backgroundColor': '#009879',
        'color': 'white',
        'padding': '12px 15px',
        'textAlign': 'left'
    }

    # Adicione um estilo para as células dos dados
    td_style = {
        'borderBottom': '1px solid #dddddd',
        'padding': '12px 15px',
        'textAlign': 'left'  # Alinhe o texto à esquerda para os dados
    }

    # Adicione um estilo para as células dos dados alternadas
    tr_even_style = {
        'backgroundColor': '#f3f3f3'
    }

    # Defina cores alternadas para as linhas
    even_row_style = tr_even_style
    odd_row_style = {}

    # Crie a estrutura da tabela HTML com os estilos aplicados
    return html.Table(
        # Adicione um estilo à tabela
        style=table_style,
        children=[
            html.Thead(
                html.Tr([html.Th(col, style=th_style) for col in dataframe.columns])
            ),
            html.Tbody([
                html.Tr([
                    html.Td(dataframe.iloc[i][col], style=td_style) for col in dataframe.columns
                ], style=even_row_style if i % 2 == 0 else odd_row_style)  # Aplique estilos alternados às linhas da tabela
                for i in range(min(len(dataframe), max_rows))
            ], style={'overflowY': 'scroll'})  # Adicione a rolagem vertical se necessário
        ]
    )



def generate_graph(df, columns, start_date, end_date):
    filtered_df = df.loc[start_date:end_date, columns]
    
    # Define a list to hold the y-axis configurations
    y_axis_config = []
    
    # Loop through each column and define a new y-axis configuration
    for i, column in enumerate(columns):
        y_axis_config.append({'title': column, 'overlaying': 'y', 'side': 'right', 'position': i * 0.1})
        
        # Define the data and layout of the figure
        data = [go.Scatter(x=filtered_df.index, y=filtered_df[column], name=column) for column in filtered_df.columns]
        layout = go.Layout(title=', '.join(columns), xaxis_title='Date')
        
        # Update the layout to include the y-axis configurations
        layout.update({'yaxis{}'.format(i + 1): y_axis_config[i] for i in range(len(y_axis_config))})
        
        # Create the figure with the data and layout
        fig = go.Figure(data=data, layout=layout)
        
        return fig
    
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
#server = app.server

app.layout = dbc.Container(fluid=True, style={'backgroundColor': colors['background'], 'maxWidth': '1200px'}, children=[
    html.H1('Forecasting North Tower (IST) Consumption (kWh)', style={'textAlign': 'center', 'color': colors['primary'], 'marginTop': '20px'}),
    html.Div(id='merged_data', children=merged_data.to_json(orient='split'), style={'display': 'none'}),
    html.Div([
        dbc.Tooltip(
            "Press to see how to interact with the DashBoard", 
            target="help-button",
            style={'fontSize': '16px', 'textAlign': 'center', 'maxWidth': '400px', 'margin': 'auto'}
        ),
        html.Button('?', id='help-button', style={'position': 'fixed', 'top': '10px', 'right': '10px', 'backgroundColor': '#009879', 'color': 'white', 'border': 'none', 'borderRadius': '50%', 'width': '80px', 'height': '80px', 'fontSize': '50px', 'fontWeight': 'bold'}),
    ]),
    dbc.Modal([
        dbc.ModalHeader("Help"),
        dbc.ModalBody([
            html.H4("How to interact with the Dashboard:"),
            html.P("This dashboard allows you to visualize and analyze the energy consumption data of the North Tower (IST)."),
            html.P("Follow the steps:"),
            html.Ul([
                html.Li("'Raw Data' - Select the columns (initial features) and the desired date range, then click on 'Apply' to visualize the raw data."),
                html.Li("'EDA' - Explore the data by selecting the desired features, along with a statistical description of them,a plot that relates both, and also a boxplot to analyze possible outliers."),
                html.Li("'Feature Selection' - Choose the features you want to test in the regression models. DON'T FORGET TO CLICK THE 'CHOOSE FEATURES' BUTTON WHERE A MESSAGE WILL APPEAR SAYING 'DONE! (right after the table) AND ONLY THEN MOVE ON TO THE NEXT TAB."),
                html.Li("'Regression Models' - Select the desired model and click on 'Train Model' to train the model and visualize the predictions. Note that the second graph compares with the 2019 data despite not being trained with it."),
                html.Li("'Model Evaluation'  - Examine the model's performance metrics."),

            ])
        ]),
        dbc.ModalFooter(
            dbc.Button("Close", id="close-help", className="ml-auto")
        ),
    ], id="help-message", size="lg"),
    dcc.Tabs(id='tabs', value='tab-1', children=[
        dcc.Tab(label='Raw Data', children=[
            html.Div([
                html.P('Click Apply to check the raw data', style={'text-align': 'center'}),
                dcc.Dropdown(
                    id='column-dropdown',
                    options=[{'label': i, 'value': i} for i in merged_data.columns],
                    value=[merged_data.columns[0]],
                    multi=True
                ),
                dcc.DatePickerRange(
                    id='date-picker',
                    min_date_allowed=merged_data.index.min(),
                    max_date_allowed=merged_data.index.max(),
                    start_date=merged_data.index.min(),
                    end_date=merged_data.index.max(),
                    calendar_orientation='vertical'
                ),
                html.Button('Apply', id='apply-button', n_clicks=0, style={'display': 'block', 'margin': 'auto'}),
                dcc.Loading(id="loading", children=[dcc.Graph(id='graph')], type="circle"),
            ])
        ]),
        dcc.Tab(label='EDA', value='tab-2', children=[
            html.Div([
                html.H2("Exploratory Data Analysis", style={'text-align': 'center'}),
                html.P([
                    "Choose the features to explore:",
                    html.Ul([
                        html.Li("Quick Statistics"),
                        html.Li("Type of graph: Scatterplot (relation between features) and Boxplot (check for outliers)")
                    ]), ], style={'text-align': 'center'}),
                dcc.Dropdown(
                    id='feature1',
                    options=[{'label': col, 'value': col} for col in merged_data.columns],
                    value=merged_data.columns[0]
                ),
                dcc.Dropdown(
                    id='feature2',
                    options=[{'label': col, 'value': col} for col in merged_data.columns],
                    value=merged_data.columns[1]
                ),
                # Quick statistics for both features
                html.Div([
                    html.Div(id='feature1-stats', className='six columns', style={'text-align': 'center'}),
                    html.Div(id='feature2-stats', className='six columns', style={'text-align': 'center'})
                ], className='row justify-content-center'),
                dcc.Graph(id='scatter-plot'),
                dcc.Dropdown(
                    id='feature-boxplot',
                    options=[{'label': col, 'value': col} for col in merged_data.columns],
                    value=merged_data.columns[1]
                ),
                dcc.Graph(id='box-plot')
            ])
        ]),
        dcc.Tab(label='Feature Selection', value='tab-3', children=[
            html.Div([
                html.P('Choose the features you want to use in the regression models', style={'text-align': 'center'}),
                html.P('Use the button below!', style={'text-align': 'center'}),
                dcc.Dropdown(
                    id='feature-dropdown',
                    options=[{'label': col, 'value': col} for col in df_dataFS.columns],
                    value=[df_dataFS.columns[0]],
                    multi=True
                ),
                html.Div(style={'text-align': 'center'}, children=[  # Div adicionada para centralizar o botão
                    html.Button('Choose Features', id='split-button', title='Click here to lock features for Regression Tab'),
                    html.P("First 10 values for each feature", style={'margin-top': '10px'})  
                ]),
                html.Div(id='feature-table-div', style={'margin': 'auto'}),  # Tabela permanece aqui
                html.Div(id='split-values'),
                html.Div([
                    html.H6(""),
                    html.Pre(id="x-values", style=white_text_style)
                ]),
                html.Div([
                    html.H6(""),
                    html.Pre(id="y-values", style=white_text_style)
                ]),
                html.Div([
                    html.H6(""),
                    html.Pre(id="x-2019-values", style=white_text_style)
                ])
            ])
        ]),
        dcc.Tab(label='Regression Models', value='tab-4', children=[
            html.Div([
                html.P('Select the model with the features you picked in the previous tab.',style={'text-align': 'center'}),
                html.P('Press the button to generate the model.',style={'text-align': 'center'}),
                dcc.Dropdown(
                    id='model-dropdown',
                    options=[
                        {'label': 'Linear Regression', 'value': 'linear'},
                        {'label': 'Decision Tree Regressor', 'value': 'decision_trees'},
                        {'label': 'Random Forest', 'value': 'random_forest'},
                        {'label': 'Gradient Boosting', 'value': 'gradient_boosting'},
                        {'label': 'Bootstrapping', 'value': 'bootstrapping'}
                    ],
                    value='linear'
                ),
                html.Button('Train Model', id='train-model-button',style={'margin-top': '20px', 'text-align': 'center'}),
            ],style={'text-align': 'center'}),
            html.Div([
                html.H2(""),
                dcc.Loading(
                    id="loading-1",
                    children=[html.Div([dcc.Graph(id="lr-graph")])]
                )
            ]),
                dcc.Graph(id='time-series-plot', figure=fig1),
        ]),
        dcc.Tab(label='Model Evaluation', value='tab-5', children=[
    html.Div([
        html.P('You can check the performace metrics in the table'),
        html.Div(id='model-performance-table')        
    ])
])
    ])
    ])
        
    

# Define the callbacks
@app.callback(
    Output('graph', 'figure'),
    Input('apply-button', 'n_clicks'),
    State('column-dropdown', 'value'),
    State('date-picker', 'start_date'),
    State('date-picker', 'end_date')
)
def update_figure(n_clicks, columns, start_date, end_date):
    if n_clicks:
        filtered_df = merged_data.loc[start_date:end_date, columns]

        # Define a list to hold the y-axis configurations
        y_axis_config = []

        # Loop through each column and define a new y-axis configuration
        for i, column in enumerate(columns):
            y_axis_config.append({'overlaying': 'y', 'side': 'right', 'position': 1 - i * 0.1})

        # Define the data and layout of the figure
        data = [{'x': filtered_df.index, 'y': filtered_df[column], 'type': 'line', 'name': column} for column in filtered_df.columns]
        layout = {'title': {'text': ', '.join(columns)}, 'xaxis': {'title': 'Date'}}

        # Update the layout to include the y-axis configurations
        layout.update({'yaxis{}'.format(i + 1): y_axis_config[i] for i in range(len(y_axis_config))})

        # Create the figure with the data and layout
        fig = {'data': data, 'layout': layout}
    else:
        fig = {'data': [], 'layout': {}}

    return fig

@app.callback(
    [Output('feature1-stats', 'children'),
     Output('feature2-stats', 'children')],
    [Input('feature1', 'value'),
     Input('feature2', 'value')]
)
def update_feature_stats(feature1, feature2):
    children = []

    if feature1:
        stats1 = merged_data[feature1].describe().reset_index().rename(columns={'index': 'Statistic'})
        table1 = html.Table([
            html.Thead(html.Tr([html.Th(col) for col in stats1.columns])),
            html.Tbody([
                html.Tr([html.Td(stats1.iloc[i][col]) for col in stats1.columns]) for i in range(len(stats1))
            ])
        ])
        children.append(html.Div([table1]))
    else:
        children.append(html.Div())

    if feature2:
        stats2 = merged_data[feature2].describe().reset_index().rename(columns={'index': 'Statistic'})
        table2 = html.Table([
            html.Thead(html.Tr([html.Th(col) for col in stats2.columns])),
            html.Tbody([
                html.Tr([html.Td(stats2.iloc[i][col]) for col in stats2.columns]) for i in range(len(stats2))
            ])
        ])
        children.append(html.Div([table2]))
    else:
        children.append(html.Div())

    return children

@app.callback(
    Output('scatter-plot', 'figure'),
    [Input('feature1', 'value'),
     Input('feature2', 'value')]
)
def update_scatter_plot(feature1, feature2):
    fig = {
        'data': [{
            'x': merged_data[feature1],
            'y': merged_data[feature2],
            'mode': 'markers',
            'marker': {'color': '#FF5733', 'size': 10, 'opacity': 0.7, 'symbol': 'circle'}  # Defina cores e estilos personalizados aqui
        }],
        'layout': {
            'title': f'{feature1} vs {feature2}',
            'xaxis': {'title': feature1},
            'yaxis': {'title': feature2},
        }
    }
    return fig

@app.callback(
    Output('box-plot', 'figure'),
    Input('feature-boxplot', 'value')
)
def update_box_plot(feature_boxplot):
    fig = go.Figure()
    fig.add_trace(go.Box(y=merged_data[feature_boxplot], name=feature_boxplot))
    fig.update_layout(title=f"Box Plot for {feature_boxplot}", title_x=0.5)
    return fig
       
    
@app.callback(
    Output('feature-table-div', 'children'),
    Input('feature-dropdown', 'value')
)
def update_feature_table(selected_features):
    if selected_features:
        global df_model
        df_model = df_dataFS[selected_features]
        table = generate_table(df_model)
        return table
    else:
        return html.Div()

@app.callback(
    Output('x-values', 'children'),
    Output('y-values', 'children'),
    Input('feature-dropdown', 'value')
)
def update_x_y(selected_features):
    global X, Y
    if selected_features:
        # Definindo X e Y com base nas características selecionadas e nos dados disponíveis
        X = df_dataFS[selected_features].values  # Features
        Y = df_final['Power (kW)'].values  # Target variable
        return str(X), str(Y)
    else:
        return "", ""


@app.callback(
    Output('split-values', 'children'),
    Input('split-button', 'n_clicks')
)
def generate_train_test_split(n_clicks):
    global X_train, X_test, y_train, y_test
    if n_clicks:
        X_train, X_test, y_train, y_test = train_test_split(X, Y)
        return 'Done!'
    else:
        return ""



# define global variables
y_pred_list = []
y_pred = []

@app.callback(
    [Output('lr-graph', 'figure'),
     Output('time-series-plot', 'figure'),
     Output('model-performance-table', 'children')],
    [Input('train-model-button', 'n_clicks')],
    [State('model-dropdown', 'value')]
)
def train_and_predict(n_clicks, model_type):
    global y_pred_list, y_pred  # access global variable

    if n_clicks is None:
        return dash.no_update 
    else:
        if model_type == 'linear':
            from sklearn.linear_model import LinearRegression
            
            # Create linear regression object
            model = LinearRegression()

        elif model_type == 'decision_trees':
            # Create decision tree regressor object
            model = DecisionTreeRegressor()

        elif model_type == 'random_forest':
            # Create random forest regressor object
            model = RandomForestRegressor()

        elif model_type == 'gradient_boosting':
            # Create gradient boosting regressor object
            model = GradientBoostingRegressor()
            
        elif model_type == 'bootstrapping':
                # Create gradient boosting regressor object
                model = BaggingRegressor()

        else:
            # Model type not recognized
            return dash.no_update

        # Train the model using all available data
        model.fit(X_train, y_train)

        # Save the trained model
        with open('model.pkl', 'wb') as file:
            pickle.dump(model, file)

        # Make predictions
        y_pred = model.predict(X_test)
        y_pred_list.append(y_pred)

        # Generate scatter plot of predicted vs actual values for lr-graph
        fig_lr = go.Figure()
        fig_lr.add_trace(go.Scatter(x=y_test, y=y_pred, mode='markers'))
        fig_lr.update_layout(title=f'{model_type.capitalize()} Predictions')
        
        # Generate time series plot of real vs predicted values
        fig_time_series = go.Figure(layout=go.Layout(title='Real vs Predicted Power Consumption'))
        fig_time_series.add_scatter(x=df_real.index, y=df_real['Power (kW)'], name='Real Power (kW)')
        fig_time_series.add_scatter(x=df_real.index, y=y_pred, name='Predicted Power (kW)')
        
        # Calculate model performance metrics
        MAE = metrics.mean_absolute_error(y_test, y_pred)
        MBE = np.mean(y_test - y_pred)
        MSE = metrics.mean_squared_error(y_test, y_pred)
        RMSE = np.sqrt(MSE)
        cvrmse = RMSE / np.mean(y_test)
        nmbe = MBE / np.mean(y_test)

        # Format the metrics as percentages with two decimal places
        cvRMSE_perc = "{:.2f}%".format(cvrmse * 100)
        NMBE_perc = "{:.2f}%".format(nmbe * 100)
        
        # Create the table with the metrics
        d = {'Metric': ['MAE', 'MBE', 'MSE', 'RMSE', 'cvRMSE', 'NMBE'],
             'Value': [MAE, MBE, MSE, RMSE, cvRMSE_perc, NMBE_perc]}
        df_metrics = pd.DataFrame(data=d)
        table = generate_table(df_metrics)
        
        
        return fig_lr, fig_time_series, table
    
@app.callback(
    Output("help-message", "is_open"),
    [Input("help-button", "n_clicks"), Input("close-help", "n_clicks")],
    [State("help-message", "is_open")],
)
def toggle_modal(n1, n2, is_open):
    if n1 or n2:
        return not is_open
    return is_open  
        
          
       
if __name__ == '__main__':
    app.run_server(debug = True)

